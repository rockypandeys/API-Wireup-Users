export const setUsersData = (payload) => (dispatch) => {
  dispatch({
    type: "SET_DATA",
    payload: payload,
  });
};

