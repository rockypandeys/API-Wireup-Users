import { combineReducers } from "redux";
import user from "./users";
export default combineReducers({
  user: user,
});
