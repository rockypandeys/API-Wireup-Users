//import { createLogger } from "redux-logger";
import { applyMiddleware, createStore } from "redux";
import reducer from "./reducer";
import thunk from "redux-thunk";

import { composeWithDevTools } from "redux-devtools-extension";

//const loggerMiddleware = createLogger();
const middleWares = composeWithDevTools(applyMiddleware(thunk));

export const store = createStore(reducer, middleWares);
