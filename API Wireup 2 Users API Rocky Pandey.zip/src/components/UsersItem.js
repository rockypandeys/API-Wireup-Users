import React, { Component } from 'react'

export class UsersItem extends Component {
    constructor(props){
        super(props);
        this.state = {
            showMore:false
        }
    }
   
    // handleSort = (e) => {
          
    //       this.props.data.id.reverse();
    //   }

    
    render() {
          let {data } = this.props;
          // const fruits = data.id; 
        return<div>
        <div>
          <div className="container-fluid"> </div>  
          {/* <button onClick={() => this.fruits.sort().reverse()} ></button> */}
          {/* <button onClick={() => this.handleSort(data.id)} ></button> */}
            {/* // <button onClick={() => this.handleSort('TYPES_SORT_REVERSE')} 
            // className="autoservices__filtersm-btn autoservices__filtersm-btn--down"></button>             */}
             </div>       
        <p><img
         src={data.avatar}
         className='profile-pic'
         alt='profile-img'
       />
       <h6>
         id : {data.id}
       </h6>

       <h6>
         First Name: {data.first_name}
       </h6>
      <h6>
         Last Name: {data.last_name}
       </h6>
      <h6>
        Email: {data.email}
       </h6>
      <h6>
      <h6>
         Gender: {data.gender}
       </h6>
         Birth date: {data.birthdate}
       </h6>
      <h6>
         Company: {data.company_name}
       </h6>
       <h6>
         Department: {data.department}
       </h6>
       <h6>
         Designation: {data.job_title}
       </h6>
       <h6>
         Address: {data.address[0].city},{data.address[0].country}
       </h6>
       <h6>
         Phone: {data.phone}
       </h6>
       </p> 
      </div> 
     
   }
 }

export default UsersItem
