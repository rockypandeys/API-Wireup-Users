import React, { Component } from 'react'
import { connect } from "react-redux";
import NavBar from './nav';
import UsersItem from './UsersItem'
import { setUsersData } from "../redux/action/users";
export class Users extends Component {

    constructor(props){
        super(props);
        this.state = {
            users:[],
            // userdata:[],
            loading: false,
            sortLogic:true
        }
    }

    async componentDidMount(){ 
        const { setUsersData } = this.props;
        let url = "https://myfakeapi.com/api/users/";
        let data = await fetch(url);
        let parsedData = await data.json()
        setUsersData(parsedData.Users)
        //setUsersData(parsedData.Users.sort())
        console.log(parsedData)
        this.setState({ totalResults: parsedData.Users.length,users:parsedData.Users})
    }
    handleSearch=async(e)=>{
       // console.log(this.props.allUsers)
        if(e.target.value.length > 0)
        {
        this.setState({ users:this.props.allUsers.filter(item=>item.first_name.toLowerCase().includes(e.target.value.toLowerCase()))})

    }
    }

    handlesort=()=>{
        let originalData = this.state.sortLogic;
        if(originalData){
            let sortData=this.props.allUsers.reverse();
            this.setState(() => ({
                users: sortData,
                sortLogic: false
              }))
        }else{
            let sortData=this.props.allUsers.reverse();
            this.setState(() => ({
                users: sortData,
                sortLogic: true
              }))
        }
    } 
    render() { 
        const { users} = this.state;
        return (<>
            <NavBar handleSearch={this.handleSearch}/>
           <button onClick={this.handlesort}>sort</button>
            {/* document.getElementById("demo").innerHTML = fruits.sort().reverse(); */}
            <div>
                <div > 
                {users.map((element)=>{
                    return <div key={element.id}>
                        <UsersItem data={element} />
                    </div> 
                })} 
                </div>     
            </div>
            </>
        )
    }
}
const mapStateToProps = (state) => ({
    allUsers: state.user.users,
  }); 
  const mapDispatchToProps = (dispatch) => ({
    setUsersData: (data) => dispatch(setUsersData(data)),
  });
  
  export default connect(mapStateToProps, mapDispatchToProps)(Users);
