import React, { Component } from 'react'

export class NavBar extends Component {
    constructor(props){
        super(props);
        this.state = {
            
        }
    }

    render() {
        return (
            <div>
                <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
                    <div>
                        <a className="navbar-brand" href="/">Users</a>
                       
                       <input type="text" onChange={this.props.handleSearch} placeholder="find..."/>
                    </div>
                    </nav>
            </div>
        )
    }
}

export default NavBar